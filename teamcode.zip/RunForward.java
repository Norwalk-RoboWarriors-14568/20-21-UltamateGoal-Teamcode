package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaCurrentGame;
import org.firstinspires.ftc.robotcore.external.tfod.TfodCurrentGame;
import com.qualcomm.robotcore.hardware.configuration.WebcamConfiguration;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;



//@Autonomous(name = "forw")
public class RunForward extends LinearOpMode {
    // Declare OpMode members.
    private DcMotor motorLeft = null;
    private DcMotor motorRight = null;

    private final int CPR_ODOMETRY = 8192;//counts per revolution for encoder, from website
    private final int ODOMETRY_WHEEL_DIAMETER = 4;
    private double CPI_DRIVE_TRAIN  =  1120 / ( 3.5 * Math.PI);
    private double leftPos = 0;
    private double rightPos = 0;
    private int timeOutCount = 0;

    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        motorLeft = hardwareMap.get(DcMotor.class, "motor_0");
        motorRight = hardwareMap.get(DcMotor.class, "motor_1") ;
        motorLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        motorLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        
        
        waitForStart();
        
        if(opModeIsActive()){
            odometryDrive(2, 0.3, 0.3, 200, 200);
            odometryDrive(2, -1, -1, -20, -20);
            //drive(1,1);
        }
        while(opModeIsActive()){
            
        }
    }
    
    public void odometryDrive(double timeOut, double leftDTSpeed, double rightDTSpeed, double mtrLeftInches, double mtrRightInches) {
            motorSetModes(DcMotor.RunMode.RUN_WITHOUT_ENCODERS);
            int newLeftTarget = motorLeft.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
            int newRightTarget = motorRight.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrRightInches);
            double thisTimeOut = this.time + timeOut;
            
            drive(leftDTSpeed, rightDTSpeed);
            while (opModeIsActive() && !IsInRange(motorLeft.getCurrentPosition(),newLeftTarget)) {
                if (this.time >= thisTimeOut) {
                    break;
                }
                
                telemetry.addData("Right motor: ",motorRight.getCurrentPosition() );
                telemetry.addData("Target Left: ", newLeftTarget);
                telemetry.addData("Target right: ", newRightTarget);
                telemetry.addData("right power: ", motorRight.getPower());
                telemetry.update();
            }

            // Stop all motion;
            drive(0, 0);
        }


/*
    public void encoderDrive(double timeOut, double leftDTSpeed, double rightDTSpeed, double mtrLeftInches, double mtrRightInches) {
        //double driveTimeSnapshot = this.time;
        motorSetModes(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorSetModes(DcMotor.RunMode.RUN_USING_ENCODER);
        // Ensure that the opmode is still active
        if (opModeIsActive()) {
            // Determine new target position, and pass to motor controller
            int newLeftTarget = motorLeft.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
            int newRightTarget = motorRight.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrRightInches);

            motorSetTargetPos(newLeftTarget, newRightTarget);
                   

            // Turn On RUN_TO_POSITION
            motorSetModes(DcMotor.RunMode.RUN_TO_POSITION);
            //drive(Math.abs(leftDTSpeed), Math.abs(rightDTSpeed));
            drive(leftDTSpeed, rightDTSpeed);
            
            double thisTimeOut = this.time + timeOut;


            // keep looping while we are still active, and there is time left, and both motors are running.
            // Note: We use (isBusy() && isBusy()) in the loop test, which means that when EITHER motor hits
            // its target position, the motion will stop.  This is "safer" in the event that the robot will
            // always end the motion as soon as possible.
            // However, if you require that BOTH motors have finished their moves before the robot continues
            // onto the next step, use (isBusy() || isBusy()) in the loop test.
            while (!isStopRequested() && opModeIsActive() && (motorLeft.isBusy() || motorRight.isBusy()) ) {

                if (this.time >= thisTimeOut) {
                    timeOutCount++;
                    break;
                }

                leftPos = motorRight.getCurrentPosition();// / CPI_DRIVE_TRAIN;
                rightPos = motorRight.getCurrentPosition();// / CPI_DRIVE_TRAIN;

                
                // Show the elapsed game time and wheel power.
                //telemetry.addData("Status", "Run Time: " + runtime.toString());
                //telemetry.addData("Motors", "left %, right %", motorLeft.getCurrentPosition(), motorRight.getCurrentPosition());
                telemetry.addData("Left motor: ", leftPos);
                telemetry.addData("Right motor: ",motorRight.getCurrentPosition() );
                telemetry.addData("Target Left: ", newLeftTarget);
                telemetry.addData("Target right: ", newRightTarget);
                //telemetry.addData("Encoder ticks:", encoder.getCurrentPosition());
                telemetry.addData("Left Inches driven", leftPos / CPI_DRIVE_TRAIN);
               
                           telemetry.addData("Left/right power: ", leftDTSpeed);
                telemetry.addData("Left power: ", motorLeft.getPower());
               telemetry.update();
            }

            // Stop all motion;
            drive(0, 0);

            // Turn off RUN_TO_POSITION
            motorSetModes(DcMotor.RunMode.RUN_USING_ENCODER);
            //sleep(250);
        }

    }*/

    public void drive(double left, double right) {
        motorLeft.setPower(left);
        motorRight.setPower(right);
    }

    public void motorSetModes(DcMotor.RunMode modeName) {
        motorLeft.setMode(modeName);
        motorRight.setMode(modeName);
    }

    public void motorSetTargetPos(int targetLeft, int targetRight) {
        motorLeft.setTargetPosition(targetLeft);
        motorRight.setTargetPosition(targetRight);
    }

    public boolean IsInRange(double countsInches, double countTarget){
        final float DEAD_RANGE = 100;
        if(Math.abs(countTarget - countsInches) <= DEAD_RANGE){
            return true;
        }
        return false;
    }

    private void displayInfo(double i, Recognition recognition) {
        // Display label info.
        // Display the label and index number for the recognition.
        telemetry.addData("label " + i, recognition.getLabel());
        telemetry.addData("width: ", recognition.getWidth() );
        telemetry.addData("height: ", recognition.getHeight() );
        telemetry.addData("H/W Ratio: ", recognition.getHeight()/recognition.getWidth() );
    }
}

