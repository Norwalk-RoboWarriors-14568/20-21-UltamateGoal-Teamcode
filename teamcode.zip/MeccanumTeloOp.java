
package org.firstinspires.ftc.teamcode.Gold14568_Skystone;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;


/**
 * All the code aside from importing, goes within a class file - essentially telling Android Studio-
 * to run this using java
 */

@TeleOp(name = "BASICTESTDOOHICKEY") //This is the name of the program that is going to be on the phone.


public class MeccanumTeloOp extends OpMode {


//*********** Experimental          Mecanums only
//*********** Rev Hub count: 2


    //TETRIX Motors        -recording the motor type as if this file ran autonomous

    private DcMotor motorLeft, motorLeft2,
            motorRight, motorRight2;
          
  
    private boolean mecanunDriveMode = true, coastMotors = true;
    private float mecanumStrafe = 0, dominantXJoystick = 0;


    /*
     * Code to run when the op mode is first enabled goes here
     * This is all automatic- it prepares the robot to run loop() without error
     */
    @Override
    public void init() {


//rev hub 1
        motorLeft = hardwareMap.dcMotor.get("motor_1");
        motorRight = hardwareMap.dcMotor.get("motor_2");
        motorLeft2 = hardwareMap.dcMotor.get("motor_3");
        motorRight2 = hardwareMap.dcMotor.get("motor_4");

        

      
        //so you don't have to wire red to black, to maintain program logic
        motorRight.setDirection(DcMotor.Direction.REVERSE);
        motorRight2.setDirection(DcMotor.Direction.REVERSE);

      //  motorActuator.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        telemetry.addLine("Drive Base TeleOp\nInit Opmode");
    }


    /**
     * The next 2 lines ends the current state of Opmode, and starts Opmode.loop()
     * This enables control of the robot via the gamepad or starts autonomous functions
     */
    @Override
    public void loop() {

        telemetry.addLine("Loop OpMode\ndPadLeft: disable mecanum strafe is " + !mecanunDriveMode +
                "\ndPadRight: enable mecanum strafe is " + mecanunDriveMode +
                "\nX: brake motors is " + !coastMotors + "\nY: coast motors is " + coastMotors);

        telemetry.addData("LeftMTR  PWR: ", motorLeft.getPower());
        telemetry.addData("RightMTR PWR: ", motorRight.getPower());
//gamepad1          -specifying the section of code giving control to gamepad1-this reduces confusion
        //else if's are required, so that a motor doesn't receive the power of multiple lines


        //allows for 3-speed joystick control


        if (Math.abs(gamepad1.left_stick_x) > 0.3) {//if right joystick is greater than 30%, start strafing
            //the +- gp1.left stick y, is a differential, taking from one side and adding to another to turn and correct the strafe
            motorLeft.setPower((-gamepad1.left_stick_x + gamepad1.right_stick_y)*0.75);
            motorLeft2.setPower((gamepad1.left_stick_x + gamepad1.right_stick_y)*0.75);
            motorRight.setPower((gamepad1.left_stick_x - gamepad1.right_stick_y)*0.75);
            motorRight2.setPower((-gamepad1.left_stick_x - gamepad1.right_stick_y)*0.75);

        } else {
            if (Math.abs(gamepad1.right_stick_x) + Math.abs(gamepad1.right_stick_y) > 1) {
                //to prevent assigning a motor more than 100% and disrupting the range of motion
                if (Math.abs(gamepad1.right_stick_x) < Math.abs(gamepad1.right_stick_y)) {
                    motorLeft.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x / 2)*0.75);
                    motorLeft2.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x / 2)*0.75);
                    motorRight.setPower((gamepad1.right_stick_y + gamepad1.right_stick_x / 2)*0.75);
                    motorRight2.setPower((gamepad1.right_stick_y + gamepad1.right_stick_x / 2)*0.75);
                } else if (Math.abs(gamepad1.right_stick_x) > Math.abs(gamepad1.right_stick_y)) {
                    motorLeft.setPower((gamepad1.right_stick_y / 2 - gamepad1.right_stick_x)*0.75);
                    motorLeft2.setPower((gamepad1.right_stick_y / 2 - gamepad1.right_stick_x)*0.75);
                    motorRight.setPower((gamepad1.right_stick_y / 2 + gamepad1.right_stick_x)*0.75);
                    motorRight2.setPower((gamepad1.right_stick_y / 2 + gamepad1.right_stick_x)*0.75);
                }
            } else {

                motorLeft.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x)*0.75);
                motorLeft2.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x)*0.75);
                motorRight.setPower((gamepad1.right_stick_y + gamepad1.right_stick_x)*0.75);
                motorRight2.setPower((gamepad1.right_stick_y+ gamepad1.right_stick_x)*0.75);
            }

        }

    /*    motorLeft.setPower(gamepad1.left_stick_y + gamepad1.left_stick_x + gamepad1.right_stick_x);
        motorLeft2.setPower(gamepad1.left_stick_y + gamepad1.left_stick_x - gamepad1.right_stick_x);
        motorRight.setPower(gamepad1.left_stick_y - gamepad1.left_stick_x - gamepad1.right_stick_x);
        motorRight2.setPower(gamepad1.left_stick_y - gamepad1.left_stick_x + gamepad1.right_stick_x);
    */


        //button code to manipulate other code/robot
       
            motorLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            motorLeft2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            motorRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            motorRight2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            coastMotors = false;
       
            motorLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            motorLeft2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            motorRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            motorRight2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);
            coastMotors = true;
       

    /*    if (gamepad1.x) {
            servoFoundation.setPosition(0.63);//up
        } else if (gamepad1.y) {
            servoFoundation.setPosition(0.35);//down
        }
     */

     
//gamepad2
        //float newServoArmSwivel;

    

//end of loop opmode programing
    }


    @Override
    public void stop() {
        telemetry.clearAll();
        telemetry.addLine("Stopped");
    }

    public void drive(double left, double right) {
        motorLeft.setPower(left);
        motorLeft2.setPower(left);
        motorRight.setPower(right);
        motorRight2.setPower(right);

    }

}
