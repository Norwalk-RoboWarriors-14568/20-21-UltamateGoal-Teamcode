package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.configuration.WebcamConfiguration;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaCurrentGame;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.tfod.TfodCurrentGame;


@Autonomous(name = "Auto Red Mecca")
public class Auto_Red_Mecanum extends LinearOpMode {
    // Declare OpMode members.
    private VuforiaCurrentGame vuforiaUltimateGoal;
    private TfodCurrentGame tfodUltimateGoal;
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor motorLeft = null;
    private DcMotor motorRight = null;
    private DcMotor motorLeft2 = null;
    private DcMotor motorRight2 = null;
    private DcMotor throwerMotor = null;
    private DcMotor motorInBelt= null;
    private DcMotor wobbleMotor = null;
    private Servo kickerServo = null;//Servo to push rings into Durflinger
    private Servo wobbleServo = null;
    private DcMotor inSpinnerMotor = null;
    //static float INTAKE_INITIAL_POS = 0f;
    static float SERVO_INITIAL_POS = 0.7f;
    static float WOBBLE_INITIAL_POS = 0.15f;
    static float WOBBLE_LOCK_POS = 0.40f;
    //private boolean buttonG2APressedLast = false;
    //private boolean buttonG2XPressedLast = false;
    private ElapsedTime timer;


    private final int CPR_ODOMETRY = 8192;//counts per revolution for encoder, from website
    private final int ODOMETRY_WHEEL_DIAMETER = 4;
    private double CPI_DRIVE_TRAIN;
    private double cpiOdometry;
    private double leftPos = 0;
    private double rightPos = 0;
    private int timeOutCount = 0;
    private VoltageSensor vs;
    private double gameTimeSnapShot = 0;

    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        cpiOdometry  = CPR_ODOMETRY / (ODOMETRY_WHEEL_DIAMETER * Math.PI);
        //CPI =     ticksPerRev / (circumerence);
        CPI_DRIVE_TRAIN = 537.6/ ( 3.1 * Math.PI);

        motorLeft  = hardwareMap.get(DcMotor.class, "motor_0");
        motorLeft2 = hardwareMap.get(DcMotor.class, "motor_2");
        motorRight  = hardwareMap.get(DcMotor.class, "motor_1");
        motorRight2 = hardwareMap.get(DcMotor.class, "motor_3");
        throwerMotor = hardwareMap.get(DcMotor.class, "motor_4");
        motorInBelt= hardwareMap.get(DcMotor.class, "motor_5");
        wobbleMotor = hardwareMap.get(DcMotor.class, "motor_6");
        kickerServo = hardwareMap.get(Servo.class, "servo_0");
        wobbleServo = hardwareMap.get(Servo.class, "servo_1" );
        inSpinnerMotor = hardwareMap.get(DcMotor.class, "motor_7" );
        vs  = this.hardwareMap.voltageSensor.iterator().next();
        timer = new ElapsedTime();//create a timer from the elapsed time class


        // Most robots need the motor on one side to be reversed to drive forward
        // Reverse the motor that runs backwards when connected directly to the battery
        motorLeft.setDirection(DcMotor.Direction.REVERSE);
        motorLeft2.setDirection(DcMotor.Direction.REVERSE);
        motorRight.setDirection(DcMotor.Direction.FORWARD);
        motorRight2.setDirection(DcMotor.Direction.FORWARD);
        motorInBelt.setDirection(DcMotor.Direction.REVERSE);
        wobbleMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorLeft2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorRight2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        inSpinnerMotor.setDirection(DcMotor.Direction.REVERSE);


        wobbleServo.setPosition(WOBBLE_LOCK_POS);
        //===============Vuforia Start
        List<Recognition> recognitions;
        double index;

        vuforiaUltimateGoal = new VuforiaCurrentGame();
        tfodUltimateGoal = new TfodCurrentGame();

        vuforiaUltimateGoal.initialize(
                "", // vuforiaLicenseKey
                hardwareMap.get(WebcamName.class, "Webcam 1"), // cameraName
                "", // webcamCalibrationFilename
                false, // useExtendedTracking
                true, // enableCameraMonitoring
                VuforiaLocalizer.Parameters.CameraMonitorFeedback.AXES, // cameraMonitorFeedback
                0, // dx
                0, // dy
                0, // dz
                0, // xAngle
                0, // yAngle
                0, // zAngle
                true); // useCompetitionFieldTargetLocations

        tfodUltimateGoal.initialize(vuforiaUltimateGoal, 0.69F, true, true);// Set min confidence threshold to 0.7
        tfodUltimateGoal.activate();// Initialize TFOD before waitForStart. Init TFOD here so the object detection labels are visible in the Camera Stream preview window on the Driver Station.
        tfodUltimateGoal.setZoom(3.5,1);
        //===============Vuforia End

        // Wait for the game to start (driver presses PLAY)
        telemetry.addLine("Ducks are pretty great");
        sleep(550);
        telemetry.update();
        waitForStart();
        runtime.reset();

        recognitions = tfodUltimateGoal.getRecognitions();// Get a list of recognitions from TFOD.
        int stackSize = -1;
        if (recognitions.size() == 0) {// If list is empty, inform the user. Otherwise, go through list and display info for each recognition.
            telemetry.addData("TFOD", "No items detected.");
            stackSize = 0;
        } else {
            if(recognitions.size() > 1){
                telemetry.addData("MORE THAN ONE RECOGNITION", " DEBUg me!");
            }
            else{
                //displayInfo(1, recognitions.get(0));
                float STACK_THRESHOLD =  69;
                if(recognitions.get(0).getHeight() > STACK_THRESHOLD){
                    stackSize = 4;
                }else{
                    stackSize = 1;
                }
            }
        }
        telemetry.update();

        //run autonomous
        if (opModeIsActive()) {
            motorSetModes(DcMotor.RunMode.STOP_AND_RESET_ENCODER);  //stop and reset encoders
            motorSetModes(DcMotor.RunMode.RUN_USING_ENCODER);       //start encoders
            if(stackSize == 0 || stackSize == -1){
                // ZERO RING 
                odometryDrive(3, 0.8,0.8,73,73,true);//strave over
                sleep(200);
                wobbleServo.setPosition(WOBBLE_INITIAL_POS);
                sleep(1000);
                odometryDrive(3, -0.8,-0.8,-70,-70,true);//strave over
                odometryDrive(1.5, -0.4,-0.4,-10,-10,true);//strave over
                odometryDrive(3, 0.6,0.6,10,10,true);//strave over
                moveArm(0.8,1);
                odometryDrive(2, -0.5,-0.5,-7,-7, false);
                wobbleServo.setPosition(WOBBLE_LOCK_POS);
                sleep(800);
                moveArm(-0.6,1.6);
                odometryDrive(2, 0.6,0.6,10,10, false);
                sleep(200);
                odometryDrive(3, 0.8,0.8,55,55,true);//strave over
                odometryDrive(3, 0.4,0.4,6,6,false);//strave over
                revDurflinger(0.73f);
                wobbleServo.setPosition(WOBBLE_INITIAL_POS);
                sleep(800);
                odometryDrive(2, -0.6,-0.6,-16,-16, false);
                odometryDrive(1,-0.7, 0.7,-22,22, false);//reverse
                odometryDrive(2, -0.6,-0.6,-12,-12, false);
                shootRings();
                odometryDrive(2,0.6,0.6,10,10, false);
                
            }
            else if(stackSize == 1){
                odometryDrive(4, 0.9,0.9,89,89,true);//strave over
                odometryDrive(1, -0.6, -0.6,-3,-3, false);//drive forward
                dropGoal(false);
                odometryDrive(1, 0.6, 0.6,3,3, false);//drive forward
                odometryDrive(4, -0.9,-0.9,-83,-83,true);//strave over
                odometryDrive(4, -0.4,-0.4,-13,-13,true);//strave over
                odometryDrive(3, 0.6,0.6,10,10,true);//strave over
                moveArm(0.5,0.3);
                odometryDrive(2, -0.5,-0.5,-18,-18, false);
                wobbleServo.setPosition(WOBBLE_LOCK_POS);
                sleep(800);
                moveArm(-0.7,0.7);
                odometryDrive(2, 0.6,0.6,15,15, false);//drive forward
                odometryDrive(4, 0.9,0.9,75,75,true);//strave over
                sleep(300);
                moveArm(0.5,0.5);
                sleep(200);
                wobbleServo.setPosition(WOBBLE_INITIAL_POS);
                sleep(400);
                odometryDrive(2, 0.6,0.6,5,5, false);
                revDurflinger(0.73f);
                odometryDrive(4, -0.6,-0.6,-29,-29,true);//strave over
                odometryDrive(2, -0.6,-0.6,-20,-20, false);
                sleep(400);
                odometryDrive(1,-0.7, 0.7,-20,20, false);//reverse
                odometryDrive(1, -0.8,-0.8,-2.5,-2.5, false);
                sleep(400);
                shootRings();
                odometryDrive(2, 1,1,15,15, false);
            }
            else if(stackSize == 4){
                //FOUR RING
                odometryDrive(4, 0.9,0.9,107,107,true);//strave over
                odometryDrive(1, -0.8, -0.8, -3,-3,false);
                odometryDrive(1, 0.4,0.4,15,15,true);//bonk wall
                wobbleServo.setPosition(WOBBLE_INITIAL_POS);
                sleep(1000);//let wobble fall
                odometryDrive(2, -0.9,-0.9,-55,-55,true);//strafe over to start
                odometryDrive(1, 0.5,0.5,6,6,false);
                odometryDrive(2, -0.9,-0.9,-55,-55,true);//strafe over to start
                sleep(300);
                odometryDrive(1, 0.8,0.8,5,5,false);
                odometryDrive(1.2, -0.4,-0.4,-12,-12,true);//bonk wall lightly
                odometryDrive(3, 0.6,0.6,9,9,true);//line up with 2nd wobble
                moveArm(0.8,1);//arm down
                odometryDrive(2, -0.5,-0.5,-16,-16, false);//backwords
                wobbleServo.setPosition(0.5f);//lock wobble
                sleep(900);//give time to lock
                moveArm(-0.6,1.7);//raise arm
                odometryDrive(2, 0.8,0.8,14,14, false);//go back to wall
                sleep(200);
                odometryDrive(4, 0.8,0.8,100,100,true);//strave over
                //odometryDrive(3, 0.4,0.4,6,6,false);//forward
                revDurflinger(0.73f);
                wobbleServo.setPosition(WOBBLE_INITIAL_POS);
                sleep(700);
                //odometryDrive(2, -0.6,-0.6,-5,-5, false);
                odometryDrive(1, -0.6,-0.6,-4,-4, true);
                odometryDrive(1,-0.7, 0.7,-20,20, false);//reverse
                odometryDrive(3, -0.9,-0.9,-45,-45,false);
                odometryDrive(3, 0.4,-0.4,4,-4,false);//straighten out
                shootRings();
                odometryDrive(2,1,1,10,10, false);               
            }
            
            telemetry.update();
        }
        tfodUltimateGoal.deactivate();//deactivate and close TFod and Vuforia
        vuforiaUltimateGoal.close();
        tfodUltimateGoal.close();
    }

    public void revDurflinger(float speed){
        double voltage = vs.getVoltage();
        double voltageScale = 0.075;
        double result = 1 + ((14 - voltage) * voltageScale);
        throwerMotor.setPower(speed * result);
    }

    public void rightTapeToShoot(){
        kickerServo.setPosition(SERVO_INITIAL_POS);
        odometryDrive(1,0.5,0.5,3,3,false);
        odometryDrive(3, -0.4, -0.4, -11, -11, true);//arc to the right
        sleep(300);
        revDurflinger(0.72f);
        odometryDrive(5,0.5,0.5,45,45,false);
        sleep(400);
        odometryDrive(3, 0.4, 0.4, 19, 19, true);//arc to the right
        odometryDrive(5,0.3,-0.3,3,-3,false);
        odometryDrive(3, 0.4, 0.4, 3, 3, false);
        shootRings();
    }

    public void startIntake(){
        motorInBelt.setPower(1);
        inSpinnerMotor.setPower(1);
    }

    public void stopIntake(){
        motorInBelt.setPower(0);
        inSpinnerMotor.setPower(0);
    }
    public void shootRings(){
        sleep(1500);
        fireRing();
        sleep(500);
        fireRing();
        sleep(500);
        fireRing();
        revDurflinger(0f);
    }

    public void moveArm(double power, double time){
        wobbleMotor.setPower(power);
        double startTime = timer.time();
        while(timer.time() - startTime < time){}
        wobbleMotor.setPower(0);
    }

    public void fireRing(){
        double startTime = timer.time();
        kickerServo.setPosition(1);
        while(timer.time() - startTime < 0.5){

        }
        kickerServo.setPosition(SERVO_INITIAL_POS);
        startTime = timer.time();
        while(timer.time() - startTime < 0.5){

        }
    }

    public void dropGoal(boolean bringBackUp){
        double startTime = timer.time();
        wobbleMotor.setPower(0.8);
        while(timer.time() - startTime < 1){//move arm down

        }
        wobbleMotor.setPower(0);
        sleep(400);
        wobbleServo.setPosition(WOBBLE_INITIAL_POS);//release thingo
        startTime = timer.time();
        while(timer.time() - startTime < 0.6){
        }
        odometryDrive(1, 0.4,0.4,5,5, false);//drive back
        if(bringBackUp){
            wobbleMotor.setPower(-0.8);
            startTime = timer.time();
            while(timer.time() - startTime < 0.5){
            }
            wobbleMotor.setPower(0);
        }
    }
    public void odometryDrive(double timeOut, double leftDTSpeed, double rightDTSpeed, double mtrLeftInches, double mtrRightInches, boolean strafe) {
        motorSetModes(DcMotor.RunMode.RUN_WITHOUT_ENCODERS);
        int newLeftTarget = motorLeft.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
        int newLeft2Target = motorLeft2.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
        int newRightTarget = motorRight.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrRightInches);
        int newRight2Target = motorRight2.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrRightInches);
        double thisTimeOut = this.time + timeOut;

        if(strafe){
            float strafeScale = 1f;//how much to scale the targets because the wheels are corkscrewing
            newLeftTarget = motorLeft.getCurrentPosition() - (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
            newRight2Target = motorRight2.getCurrentPosition() - (int) (CPI_DRIVE_TRAIN * mtrRightInches);
        }

        drive(leftDTSpeed, rightDTSpeed, strafe);
        while (opModeIsActive() && !IsInRange(motorLeft.getCurrentPosition(),newLeftTarget)
                && !IsInRange(motorLeft2.getCurrentPosition(),newLeft2Target)
                && !IsInRange(motorRight.getCurrentPosition(),newRightTarget)
                && !IsInRange(motorRight2.getCurrentPosition(),newRight2Target)) {
            if (this.time >= thisTimeOut) {
                break;
            }

            telemetry.addData("Right motor: ",motorRight.getCurrentPosition() );
            telemetry.addData("Target Left: ", newLeftTarget);
            telemetry.addData("Target right: ", newRightTarget);
            telemetry.addData("right power: ", motorRight.getPower());
            telemetry.update();
        }

        // Stop all motion;
        drive(0, 0, strafe);
    }

    public void drive(double left, double right, boolean strafe) {
        //telemetry.addData("Left/right power: ", left, right);
        telemetry.update();
        if(!strafe){
            motorLeft.setPower(left);
            motorRight.setPower(right);
            motorLeft2.setPower(left);
            motorRight2.setPower(right);
        }else{
            motorLeft.setPower(-left);
            motorRight.setPower(right);
            motorLeft2.setPower(left);
            motorRight2.setPower(-right);
        }
    }

    public void motorSetModes(DcMotor.RunMode modeName) {
        motorLeft.setMode(modeName);
        motorRight.setMode(modeName);
    }

    public void motorSetTargetPos(int targetLeft, int targetRight) {
        motorLeft.setTargetPosition(targetLeft);
        motorRight.setTargetPosition(targetRight);
    }

    public boolean IsInRange(double inches, double target){
        final float DEAD_RANGE = 20;
        if(Math.abs(target - inches) <= DEAD_RANGE){
            return true;
        }
        return false;
    }

    private void displayInfo(double i, Recognition recognition) {
        // Display label info.
        // Display the label and index number for the recognition.
        telemetry.addData("label " + i, recognition.getLabel());
        telemetry.addData("width: ", recognition.getWidth() );
        telemetry.addData("height: ", recognition.getHeight() );
        telemetry.addData("H/W Ratio: ", recognition.getHeight()/recognition.getWidth() );
    }
}
