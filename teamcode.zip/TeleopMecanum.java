package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.CRServo;

@TeleOp(name="Teleop Mechanum", group="Linear Opmode")
public class TeleopMecanum extends LinearOpMode {

    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor motorLeft = null;
    private DcMotor motorRight = null;
    private DcMotor motorLeft2 = null;
    private DcMotor motorRight2 = null;
    private DcMotor throwerMotor = null;
    private DcMotor motorIntakeBelt = null;
    private DcMotor wobbleMotor = null;
    private Servo kickerServo = null;//Servo to push rings into Durflinger
    private Servo wobbleServo = null;
    private DcMotor intakeFrontMotor = null;
    static float SERVO_INITIAL_POS = 0.7f;
    static float GRABBER_INITIAL_POS = 0.0f;//wobble graber servo initial pos
    private boolean buttonG2APressedLast = false;
    private boolean buttonG2XPressedLast = false;


    private ElapsedTime timer;

    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();

        // Initialize the hardware variables. Note that the strings used here as parameters
        // to 'get' must correspond to the names assigned during the robot configuration
        // step (using the FTC Robot Controller app on the phone).
        motorLeft  = hardwareMap.get(DcMotor.class, "motor_0");
        motorLeft2 = hardwareMap.get(DcMotor.class, "motor_2");
        motorRight  = hardwareMap.get(DcMotor.class, "motor_1");
        motorRight2 = hardwareMap.get(DcMotor.class, "motor_3");
        throwerMotor = hardwareMap.get(DcMotor.class, "motor_4");
        motorIntakeBelt = hardwareMap.get(DcMotor.class, "motor_5");
        wobbleMotor = hardwareMap.get(DcMotor.class, "motor_6");
        kickerServo = hardwareMap.get(Servo.class, "servo_0");
        wobbleServo = hardwareMap.get(Servo.class, "servo_1" );
        intakeFrontMotor = hardwareMap.get(DcMotor.class, "motor_7");
        timer = new ElapsedTime();//create a timer from the elapsed time class

        // Most robots need the motor on one side to be reversed to drive forward
        // Reverse the motor that runs backwards when connected directly to the battery
        motorRight.setDirection(DcMotor.Direction.REVERSE);
        motorRight2.setDirection(DcMotor.Direction.REVERSE);

        motorRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorRight2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorLeft2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        throwerMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        wobbleMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        kickerServo.setDirection(Servo.Direction.FORWARD);//set the servo direction
        motorIntakeBelt.setDirection(DcMotor.Direction.REVERSE);
        intakeFrontMotor.setDirection(DcMotor.Direction.REVERSE);
        //grabberServo.setDirection(Servo.Direction.FORWARD);//set the servo direction



        // Wait for the game to start (driver presses PLAY)
        waitForStart();
        runtime.reset();
        timer.startTime();
        kickerServo.setPosition(SERVO_INITIAL_POS);
        wobbleServo.setPosition(GRABBER_INITIAL_POS);
        //intakeFrontMotor.setPosition(INTAKE_INITIAL_POS);

        double startKickTime = 9999;//the time the button was pressed to move the servo (set high so it doesn't hit)
        double throwerPower = 0;//declare outside while loop to persist the value between loops
        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {
            if(gamepad2.y){//if b button pressed
                kickerServo.setPosition(1);//set position
                startKickTime = timer.time();//start the timer so it knows when to turn around
            }
            if(timer.time() - startKickTime > 0.3){//if its been moving for > 0.3 seconds
                kickerServo.setPosition(SERVO_INITIAL_POS);//reset back to zero
                startKickTime = 99999;//set kickTime back to value that doesn't trigger this
            }

            if(gamepad2.x && !buttonG2XPressedLast){
                if(Math.abs(wobbleServo.getPosition() - GRABBER_INITIAL_POS) < 0.01){
                    wobbleServo.setPosition(0.52);
                }
                else if(Math.abs(wobbleServo.getPosition() - 0.52) < 0.01){
                    wobbleServo.setPosition(GRABBER_INITIAL_POS);
                }
            }
            buttonG2XPressedLast = gamepad2.x;

            if(gamepad2.a && !buttonG2APressedLast){
                if (motorIntakeBelt.getPower() != 0) {
                    motorIntakeBelt.setPower(0);
                    intakeFrontMotor.setPower(0);
                }else{
                    motorIntakeBelt.setPower(1);
                    intakeFrontMotor.setPower(1);
                }
            }
            buttonG2APressedLast = gamepad2.a;

            if(gamepad2.dpad_right){//if holding right on dpad, reverse it
                motorIntakeBelt.setPower(-1);
                intakeFrontMotor.setPower(-1);
            }
            buttonG2APressedLast = gamepad2.a;

            if(gamepad2.dpad_up){
                wobbleMotor.setPower(-0.6);
            }
            else if(gamepad2.dpad_down){
                wobbleMotor.setPower(0.6);
            }
            else{
                wobbleMotor.setPower(0);
            }
            //Thrower code to set different speeds
            if(gamepad2.left_bumper){
                throwerPower = 0f;
            }
            else if(gamepad2.left_trigger > 0.2f){
                throwerPower = 0.65;
            }
            else if(gamepad2.right_bumper){
                throwerPower = 0.7f;
            }
            else if(gamepad2.right_trigger > 0.2f){
                throwerPower = 0.8f;
            }
            throwerMotor.setPower(throwerPower);

            float powerModification = 0.75f;
            if(gamepad1.right_bumper){powerModification = 0.5f;}
            else if(gamepad1.left_bumper){powerModification = 1f;}

            if (Math.abs(gamepad1.left_stick_x) > 0.3) {//if right joystick is greater than 30%, start strafing
                //the +- gp1.left stick y, is a differential, taking from one side and adding to another to turn and correct the strafe
                motorLeft.setPower((-gamepad1.left_stick_x + gamepad1.right_stick_y)*powerModification);
                motorLeft2.setPower((gamepad1.left_stick_x + gamepad1.right_stick_y)*powerModification);
                motorRight.setPower((gamepad1.left_stick_x - gamepad1.right_stick_y)*powerModification);
                motorRight2.setPower((-gamepad1.left_stick_x - gamepad1.right_stick_y)*powerModification);

            } else {
                if (Math.abs(gamepad1.right_stick_x) + Math.abs(gamepad1.right_stick_y) > 1) {
                    //to prevent assigning a motor more than 100% and disrupting the range of motion
                    if (Math.abs(gamepad1.right_stick_x) < Math.abs(gamepad1.right_stick_y)) {
                        motorLeft.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x / 2)*powerModification);
                        motorLeft2.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x / 2)*powerModification);
                        motorRight.setPower((gamepad1.right_stick_y + gamepad1.right_stick_x / 2)*powerModification);
                        motorRight2.setPower((gamepad1.right_stick_y + gamepad1.right_stick_x / 2)*powerModification);
                    } else if (Math.abs(gamepad1.right_stick_x) > Math.abs(gamepad1.right_stick_y)) {
                        motorLeft.setPower((gamepad1.right_stick_y / 2 - gamepad1.right_stick_x)*powerModification);
                        motorLeft2.setPower((gamepad1.right_stick_y / 2 - gamepad1.right_stick_x)*powerModification);
                        motorRight.setPower((gamepad1.right_stick_y / 2 + gamepad1.right_stick_x)*powerModification);
                        motorRight2.setPower((gamepad1.right_stick_y / 2 + gamepad1.right_stick_x)*powerModification);
                    }
                } else {

                    motorLeft.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x)*powerModification);
                    motorLeft2.setPower((gamepad1.right_stick_y - gamepad1.right_stick_x)*powerModification);
                    motorRight.setPower((gamepad1.right_stick_y + gamepad1.right_stick_x)*powerModification);
                    motorRight2.setPower((gamepad1.right_stick_y+ gamepad1.right_stick_x)*powerModification);
                }

            }

            // Show the elapsed game time and wheel power.
            telemetry.addData("Status", "Run Time: " + runtime.toString());
            telemetry.addData("MotorsFront", "left (%.2f), right (%.2f)", motorLeft.getPower(), motorRight.getPower());
            telemetry.addData("MotorsBack ", "left (%.2f), right (%.2f)", motorLeft2.getPower(), motorRight2.getPower());
            telemetry.update();

        }
    }
}