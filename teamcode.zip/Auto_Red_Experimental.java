package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.configuration.WebcamConfiguration;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaCurrentGame;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.tfod.TfodCurrentGame;


@Autonomous(name = "Auto Red Experiment")
public class Auto_Red_Experimental extends LinearOpMode {
    // Declare OpMode members.
    private VuforiaCurrentGame vuforiaUltimateGoal;
    private TfodCurrentGame tfodUltimateGoal;
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor motorLeft = null;
    private DcMotor motorRight = null;
    private DcMotor motorLeft2 = null;
    private DcMotor motorRight2 = null;
    private DcMotor throwerMotor = null;
    private DcMotor motorInBelt= null;
    private DcMotor wobbleMotor = null;
    private Servo kickerServo = null;//Servo to push rings into Durflinger
    private Servo wobbleServo = null;
    private DcMotor inSpinnerMotor = null;
    //static float INTAKE_INITIAL_POS = 0f;
    static float SERVO_INITIAL_POS = 0.7f;
    static float WOBBLE_INITIAL_POS = 0.5f;
    //private boolean buttonG2APressedLast = false;
    //private boolean buttonG2XPressedLast = false;
    private ElapsedTime timer;


    private final int CPR_ODOMETRY = 8192;//counts per revolution for encoder, from website
    private final int ODOMETRY_WHEEL_DIAMETER = 4;
    private double CPI_DRIVE_TRAIN;
    private double cpiOdometry;
    private double leftPos = 0;
    private double rightPos = 0;
    private int timeOutCount = 0;
    private double gameTimeSnapShot = 0;

    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        cpiOdometry  = CPR_ODOMETRY / (ODOMETRY_WHEEL_DIAMETER * Math.PI);
        //CPI =     ticksPerRev / (circumerence);
        CPI_DRIVE_TRAIN =  /*1120*/ 537.6/ ( 3.5 * Math.PI);

        motorLeft  = hardwareMap.get(DcMotor.class, "motor_0");
        motorLeft2 = hardwareMap.get(DcMotor.class, "motor_2");
        motorRight  = hardwareMap.get(DcMotor.class, "motor_1");
        motorRight2 = hardwareMap.get(DcMotor.class, "motor_3");
        throwerMotor = hardwareMap.get(DcMotor.class, "motor_4");
        motorInBelt= hardwareMap.get(DcMotor.class, "motor_5");
        wobbleMotor = hardwareMap.get(DcMotor.class, "motor_6");
        kickerServo = hardwareMap.get(Servo.class, "servo_0");
        wobbleServo = hardwareMap.get(Servo.class, "servo_1" );
        inSpinnerMotor = hardwareMap.get(DcMotor.class, "motor_7" );
        timer = new ElapsedTime();//create a timer from the elapsed time class


        // Most robots need the motor on one side to be reversed to drive forward
        // Reverse the motor that runs backwards when connected directly to the battery
        motorLeft.setDirection(DcMotor.Direction.REVERSE);
        motorLeft2.setDirection(DcMotor.Direction.REVERSE);
        motorRight.setDirection(DcMotor.Direction.FORWARD);
        motorRight2.setDirection(DcMotor.Direction.FORWARD);
        motorInBelt.setDirection(DcMotor.Direction.REVERSE);
        wobbleMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorLeft2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        motorRight2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        inSpinnerMotor.setDirection(DcMotor.Direction.REVERSE);



        //===============Vuforia Start
        List<Recognition> recognitions;
        double index;

        vuforiaUltimateGoal = new VuforiaCurrentGame();
        tfodUltimateGoal = new TfodCurrentGame();

        vuforiaUltimateGoal.initialize(
                "", // vuforiaLicenseKey
                hardwareMap.get(WebcamName.class, "Webcam 1"), // cameraName
                "", // webcamCalibrationFilename
                false, // useExtendedTracking
                true, // enableCameraMonitoring
                VuforiaLocalizer.Parameters.CameraMonitorFeedback.AXES, // cameraMonitorFeedback
                0, // dx
                0, // dy
                0, // dz
                0, // xAngle
                0, // yAngle
                0, // zAngle
                true); // useCompetitionFieldTargetLocations

        tfodUltimateGoal.initialize(vuforiaUltimateGoal, 0.69F, true, true);// Set min confidence threshold to 0.7
        tfodUltimateGoal.activate();// Initialize TFOD before waitForStart. Init TFOD here so the object detection labels are visible in the Camera Stream preview window on the Driver Station.
        tfodUltimateGoal.setZoom(2.3,1);
        //===============Vuforia End
        // Wait for the game to start (driver presses PLAY)
        telemetry.addLine("This shouldn't take this long");
        sleep(550);
        telemetry.update();
        waitForStart();
        runtime.reset();

        recognitions = tfodUltimateGoal.getRecognitions();// Get a list of recognitions from TFOD.
        int stackSize = -1;
        if (recognitions.size() == 0) {// If list is empty, inform the user. Otherwise, go through list and display info for each recognition.
            telemetry.addData("TFOD", "No items detected.");
            stackSize = 0;
        } else {
            if(recognitions.size() > 1){
                telemetry.addData("MORE THAN ONE RECOGNITION", " DEBUg me!");
            }
            else{
                //displayInfo(1, recognitions.get(0));
                float STACK_THRESHOLD =  69;
                if(recognitions.get(0).getHeight() > STACK_THRESHOLD){
                    stackSize = 4;
                }else{
                    stackSize = 1;
                }
            }
        }
        telemetry.update();

        // run until the end of the match (driver presses STOP)
        if (opModeIsActive()) {
            motorSetModes(DcMotor.RunMode.STOP_AND_RESET_ENCODER);  //stop and reset encoders
            motorSetModes(DcMotor.RunMode.RUN_USING_ENCODER);       //start encoders
            if(stackSize == 0){
                rightTapeToShoot();
                odometryDrive(2, 0.6,0.6,22,22,false);
                odometryDrive(2,-0.5, 0.5,-24,24, false);//turn
                odometryDrive(2, -0.6,-0.6,-9,-9,false);
                dropGoal();
            }
            else if(stackSize == 1){
                telemetry.addData("RECOGNITIONS: ", "1");
                telemetry.update();
                rightTapeToShoot();
                odometryDrive(2, 0.6,0.6,22,22,false);
                odometryDrive(3,-0.4, 0.4,-48,48, false);//turn
                dropGoal();
                //EXPERIMENTAL GRABBY GRABB
                startIntake();
                revDurflinger(0.73f);
                odometryDrive(3, 0.4,0.4,42,42,false);
                odometryDrive(2,-0.5, 0.5,-48,48, false);//turn
                stopIntake();
                odometryDrive(2, 0.4,0.4,22,22,false);
                odometryDrive(5,-0.3,0.3,-2,2,false);
                sleep(500);
                fireRing();
                odometryDrive(1, 0.7,0.7,18,18,false);
            }
            else if(stackSize == 4){
                telemetry.addData("RECOGNITIONS: ", "4");
                telemetry.update();
                rightTapeToShoot();
                odometryDrive(2, 0.6,0.6,66,66,false);
                odometryDrive(2,-0.5, 0.5,-28,28, false);//turn
                odometryDrive(2, -0.6,-0.6,-4,-4,false);
                dropGoal();
                //odometryDrive(2, 0.6,0.6,2,2,false);
                odometryDrive(2,-0.5,0.5,-20,20, false);//turn
                odometryDrive(3, 0.8,0.8,67,67,false);
                odometryDrive(2, -0.6,-0.6,-12,-12,false);
                startIntake();
                odometryDrive(3, 0.3,0.3,32,32,false);
                revDurflinger(0.73f);
                odometryDrive(2,-0.5, 0.5,-48,48, false);//turn
                odometryDrive(3, 0.4,0.4,20,20,false);
                stopIntake();
                shootRings();
                odometryDrive(2, 0.6,0.6,9,9,false);
                
                //EXPERIMEN
            }
            telemetry.update();
        }
        tfodUltimateGoal.deactivate();//deactivate and close TFod and Vuforia
        vuforiaUltimateGoal.close();
        tfodUltimateGoal.close();
    }

    public void revDurflinger(float speed){
        throwerMotor.setPower(speed);
    }

    public void rightTapeToShoot(){
        kickerServo.setPosition(SERVO_INITIAL_POS);
        wobbleServo.setPosition(0.13);
        odometryDrive(5,0.3,0.3,3,3,false);
        odometryDrive(3, -0.4, -0.4, -11, -11, true);//arc to the right
        sleep(300);
        revDurflinger(0.74f);
        odometryDrive(5,0.5,0.52,45,45,false);
        sleep(400);
        odometryDrive(3, 0.4, 0.4, 19, 19, true);//arc to the right
        odometryDrive(5,-0.3,0.3,-2.5,2.5,false);
        shootRings();
    }

    public void startIntake(){
        motorInBelt.setPower(1);
        inSpinnerMotor.setPower(1);
    }

    public void stopIntake(){
        motorInBelt.setPower(0);
        inSpinnerMotor.setPower(0);
    }
    public void shootRings(){
        sleep(1500);
        fireRing();
        sleep(500);
        fireRing();
        sleep(500);
        fireRing();
        revDurflinger(0f);
    }

    public void fireRing(){
        double startTime = timer.time();
        kickerServo.setPosition(1);
        while(timer.time() - startTime < 0.5){

        }
        kickerServo.setPosition(SERVO_INITIAL_POS);
        startTime = timer.time();
        while(timer.time() - startTime < 0.5){

        }
    }

    public void dropGoal(){
        double startTime = timer.time();
        wobbleMotor.setPower(0.8);
        while(timer.time() - startTime < 1.3){//move arm down

        }
        wobbleMotor.setPower(0);
        wobbleServo.setPosition(WOBBLE_INITIAL_POS);//release thingo
        startTime = timer.time();
        while(timer.time() - startTime < 0.6){
        }
        odometryDrive(1, 0.4,0.4,5,5, false);//drive back
        sleep(200);
        wobbleMotor.setPower(-0.8);
        startTime = timer.time();
        while(timer.time() - startTime < 0.9){
        }
        wobbleMotor.setPower(0);
    }
    public void odometryDrive(double timeOut, double leftDTSpeed, double rightDTSpeed, double mtrLeftInches, double mtrRightInches, boolean strafe) {
        motorSetModes(DcMotor.RunMode.RUN_WITHOUT_ENCODERS);
        int newLeftTarget = motorLeft.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
        int newLeft2Target = motorLeft2.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
        int newRightTarget = motorRight.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrRightInches);
        int newRight2Target = motorRight2.getCurrentPosition() + (int) (CPI_DRIVE_TRAIN * mtrRightInches);
        double thisTimeOut = this.time + timeOut;

        if(strafe){
            float strafeScale = 1f;//how much to scale the targets because the wheels are corkscrewing
            newLeftTarget = motorLeft.getCurrentPosition() - (int) (CPI_DRIVE_TRAIN * mtrLeftInches);
            newRight2Target = motorRight2.getCurrentPosition() - (int) (CPI_DRIVE_TRAIN * mtrRightInches);
        }

        drive(leftDTSpeed, rightDTSpeed, strafe);
        while (opModeIsActive() && !IsInRange(motorLeft.getCurrentPosition(),newLeftTarget)
                && !IsInRange(motorLeft2.getCurrentPosition(),newLeft2Target)
                && !IsInRange(motorRight.getCurrentPosition(),newRightTarget)
                && !IsInRange(motorRight2.getCurrentPosition(),newRight2Target)) {
            if (this.time >= thisTimeOut) {
                break;
            }

            telemetry.addData("Right motor: ",motorRight.getCurrentPosition() );
            telemetry.addData("Target Left: ", newLeftTarget);
            telemetry.addData("Target right: ", newRightTarget);
            telemetry.addData("right power: ", motorRight.getPower());
            telemetry.update();
        }

        // Stop all motion;
        drive(0, 0, strafe);
    }

    public void drive(double left, double right, boolean strafe) {
        //telemetry.addData("Left/right power: ", left, right);
        telemetry.update();
        if(!strafe){
            motorLeft.setPower(left);
            motorRight.setPower(right);
            motorLeft2.setPower(left);
            motorRight2.setPower(right);
        }else{
            motorLeft.setPower(-1*left);
            motorRight.setPower(right);
            motorLeft2.setPower(left);
            motorRight2.setPower(-1*right);
        }
    }

    public void motorSetModes(DcMotor.RunMode modeName) {
        motorLeft.setMode(modeName);
        motorRight.setMode(modeName);
    }

    public void motorSetTargetPos(int targetLeft, int targetRight) {
        motorLeft.setTargetPosition(targetLeft);
        motorRight.setTargetPosition(targetRight);
    }

    public boolean IsInRange(double inches, double target){
        final float DEAD_RANGE = 20;
        if(Math.abs(target - inches) <= DEAD_RANGE){
            return true;
        }
        return false;
    }

    private void displayInfo(double i, Recognition recognition) {
        // Display label info.
        // Display the label and index number for the recognition.
        telemetry.addData("label " + i, recognition.getLabel());
        telemetry.addData("width: ", recognition.getWidth() );
        telemetry.addData("height: ", recognition.getHeight() );
        telemetry.addData("H/W Ratio: ", recognition.getHeight()/recognition.getWidth() );
    }
}
